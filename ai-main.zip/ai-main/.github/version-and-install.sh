#!/usr/bin/env bash

pnpm changeset version
# pnpm install --no-frozen-lockfile
