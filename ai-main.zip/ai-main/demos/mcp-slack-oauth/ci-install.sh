#!/bin/bash
npm install --no-audit --no-fund

