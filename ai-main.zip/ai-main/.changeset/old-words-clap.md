---
"workers-ai-provider": minor
---

feat: adds support for embed and embedMany
