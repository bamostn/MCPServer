export type WorkersAIImageConfig = {
	provider: string;
	binding: Ai;
	gateway?: GatewayOptions;
};
