export type WorkersAIImageSettings = {
	maxImagesPerCall?: number;
};
